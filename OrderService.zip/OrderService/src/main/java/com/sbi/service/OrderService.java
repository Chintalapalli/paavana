package com.sbi.service;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.Builder;

import com.sbi.dao.OrderRepository;
import com.sbi.entity.Order;
import com.sbi.model.DataRequest;
import com.sbi.model.DataResponse;
import com.sbi.model.OrderRequest;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import reactor.core.publisher.Mono;

@Service
public class OrderService {
	
	private OrderRepository orderRepository;
	private WebClient.Builder webClientBuilder;
	
	public OrderService(OrderRepository orderRepository, Builder webClientBuilder) {
		super();
		this.orderRepository = orderRepository;
		this.webClientBuilder = webClientBuilder;
	}

	public void placeOrder(OrderRequest orderRequest) {
		
		Map productMap = getProductsDetails(orderRequest.getProductId());
		System.out.println("productDetails:::"+productMap);
		
		int orderQuantity = orderRequest.getQuantity();
		if(!productMap.isEmpty()) {
			String quantity = (String) productMap.get("quantity");
			int productQuantity = Integer.parseInt(quantity);
	            System.out.println("productQuantity:::"+productQuantity);
	            if(orderQuantity <= productQuantity){
	            	
	            	Order order = new Order();
	        		order.setProductId(orderRequest.getProductId());
	        		order.setOrderAmount(orderRequest.getAmount());
	        		order.setOrderDate(Instant.now());
	        		order.setQuantity(orderRequest.getQuantity());
	        		order.setOrderStatus("PLACED");
	        		Order id = orderRepository.save(order);
	        		
	        		productQuantity = productQuantity - orderQuantity;
	        		System.out.println("Remaining Stock::"+productQuantity);
	        		String count = String.valueOf(productQuantity);
	        		productMap.put("quantity", quantity);
	        		
	        		int id1 = (int) productMap.get("productId");
	        		long productID = id1;
	        		System.out.println("productID:::"+productID);
	        		DataRequest dataRequest = new DataRequest();
	        		dataRequest.setProductId(productID);
	        		dataRequest.setProductName((String)productMap.get("productName"));
	        		dataRequest.setPrice((String)productMap.get("price"));
	        		dataRequest.setQuantity((String)productMap.get("quantity"));
					
	                DataResponse response= updateProductDetails(dataRequest);
	               System.out.println("response: " + response.toString());
	            }else{
	                throw new IllegalArgumentException("Product Quantity Exceeded Order Count");
	            }
	        }
		}
	
	@CircuitBreaker(name = "productService",fallbackMethod = "orderFallBackMethod")
	public Map getProductsDetails(Long long1) {
		String url ="http://localhost:9090/api/product/fetchProduct/"+long1;
		System.out.println("product Url::"+url);
		return webClientBuilder.build().get().uri(url)
				.accept(org.springframework.http.MediaType.APPLICATION_JSON)
				.retrieve().bodyToMono(Map.class)
				.block();
		}
	
	@CircuitBreaker(name = "productService",fallbackMethod = "updateProductDetailsFallback")
	 public DataResponse updateProductDetails(DataRequest productMap) {
	        Mono<DataResponse> response = webClientBuilder.build().put()
	                .uri("http://localhost:9090/api/product/update")
	                .contentType(org.springframework.http.MediaType.APPLICATION_JSON)
	                .bodyValue(productMap)
	                .retrieve()
	                .bodyToMono(DataResponse.class);
	        return response.block();
	    }

	public Map<String, Object> orderFallbackMethod(Long long1, Throwable t) {
	    Map<String, Object> response = new HashMap<>();
	    response.put("message", "Fallback: Order service is currently unavailable.");
	    System.out.println(response);
	    return response;
	}
	
	public DataResponse updateProductDetailsFallback(DataRequest productMap, Throwable t) {
	    DataResponse response = new DataResponse();
	    response.setStatus("Failed");
	    response.setMessage("Fallback: Unable to update product details.");
	    return response;
	}
	
}
