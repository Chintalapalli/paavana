package com.sbi.controller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.config.OrderProducer;
import com.sbi.entity.Order;
import com.sbi.model.OrderRequest;
import com.sbi.service.OrderService;

@RestController
@RequestMapping("/api/order")
public class OrderController {
	
	private final OrderService orderService;
	
	private final OrderProducer orderProducer;

	public OrderController(OrderService orderService,OrderProducer orderProducer) {
		this.orderService = orderService;
		this.orderProducer = orderProducer;
	}
	
	@PostMapping("/placeOrder")
	public ResponseEntity<String> placeOrder(@RequestBody OrderRequest orderReuest){
		orderService.placeOrder(orderReuest);
		//Calling kafka producer
		orderProducer.sendOrder(orderReuest);
		String msg = "Order placed successfully.";
		return new ResponseEntity<String>(msg,HttpStatus.ACCEPTED);
	}

	@GetMapping("/{id}/getProduct")
	public ResponseEntity<?> getProduct(@PathVariable long id ){
		System.out.println("product ID:::"+id);
		Map product = orderService.getProductsDetails(id);
		System.out.println("Product Details::"+product);
		return new ResponseEntity<>(product,HttpStatus.OK);
	}
	
	
}
