package com.sbi.model;

public enum PaymentMode {
	CASH,DEBIT_CARD,CREDIT_CARD

}
