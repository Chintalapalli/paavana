package com.sbi.model;


import java.util.Map;


public class DataResponse {

    @Override
	public String toString() {
		return "DataResponse [productMap=" + productMap + "]";
	}

	private Map<String,Integer> productMap;
	
	private String status;
	private String message;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

}
